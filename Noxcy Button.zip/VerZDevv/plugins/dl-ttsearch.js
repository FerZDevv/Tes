// Thanks to SSA Team
import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, args, command, text }) => {
if (!text) throw `Searching?`
m.reply(wait)
try {
let anu = await fetch(`https://ssa-api.vercel.app/api/tiktoksearch?query=${text}`)
let result = await anu.json()
await conn.sendFile(m.chat, result.data.response.media.nowm, 'anu.mp4', `*Description:* ${result.data.response.title}`, m)
} catch (e) {
}
}
handler.help = ['ttsearch']
handler.tags = ['dl']
handler.command = /^(ttsearch)$/i
handler.diamond = true

export default handler