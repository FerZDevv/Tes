/*
follow the channel
https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
don't delete this wm!!
*/
import axios from 'axios'
import { Sticker } from 'wa-sticker-formatter'
import uploadImage from '../lib/uploadImage.js'
let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
    try {
        let q = m.quoted ? m.quoted: m
        let mime = (q.msg || q).mimetype || ''
        let txt = text ? text: typeof q.text == 'string' ? q.text: ''
        if (!txt) throw `Example: ${usedPrefix + command} halo`
        let avatar = await conn.profilePictureUrl(q.sender, 'image').catch(_ => 'https://i.ibb.co/2WzLyGk/profile.jpg')
        avatar = /tele/.test(avatar) ? avatar: await uploadImage((await conn.getFile(avatar)).data)
        if (!/image\/(jpe?g|png)/.test(mime)) {
            let req = await fakechat(txt, q.name, avatar)
            let stiker = await createSticker(req, false, packname, author)
            conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
        } else {
            let img = await q.download()
            let url = await uploadImage(img)
            let req = await fakechatImg(url, txt, q.name, avatar)
            let stiker = await createSticker(req, false, packname, author)
            conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
        }
    } catch (e) {
        throw e
    }
}
handler.help = ['qc']
handler.tags = ['sticker']
handler.command = /^(qc)$/i
export default handler
//follow https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
async function fakechat(text, name, url) {
    let body = {
        "type": "quote",
        "format": "webp",
        "backgroundColor": "#FFFFFF",
        "width": 512,
        "height": 512,
        "scale": 2,
        "messages": [{
        "avatar": true,
        "from": {
            "first_name": name,
            "language_code": "en",
            "name": name,
            "photo": {
            "url": url
            }
        },
        "text": text,
        "replyMessage": {}
        }]
    }
    let res = await axios.post('https://quotly.netorare.codes/generate', body);
    return Buffer.from(res.data.result.image, "base64");
}

async function fakechatImg(url, text, name, avatar) {
    let body = {
        "type": "quote",
        "format": "png",
        "backgroundColor": "#FFFFFF",
        "width": 512,
        "height": 768,
        "scale": 2,
        "messages": [{
        "entities": [],
        "media": {
            "url": url
        },
        "avatar": true,
        "from": {
            "id": 1,
            "name": name,
            "photo": {
            "url": avatar
            }
        },
        "text": text,
        "replyMessage": {}
        }]
    }
    let res = await axios.post('https://quotly.netorare.codes/generate', body);
    return Buffer.from(res.data.result.image, "base64");
}

async function createSticker(req, url, packName, authorName, quality) {
    let stickerMetadata = {
        type: 'full',
        pack: packname,
        author: author,
        quality
    }
return (new Sticker(req ? req: url, stickerMetadata)).toBuffer()
}

/*
import { sticker } from "../lib/sticker.js";
import axios from "axios";

let handler = async (m, { conn, args, usedPrefix, command }) => {
	let text;
	if (args.length >= 1) {
		text = args.slice(0).join(" ");
	} else if (m.quoted && m.quoted.text) {
		text = m.quoted.text;
	} else throw "Input teks atau reply teks yang ingin di jadikan quote!";
	await m.reply(wait);

	let pp = await conn
		.profilePictureUrl(m.sender, "image")
		.catch((_) => "https://telegra.ph/file/a2ae6cbfa40f6eeea0cf1.jpg");

	const obj = {
		type: "quote",
		format: "png",
		backgroundColor: getRandomHexColor().toString(),
		width: 512,
		height: 768,
		scale: 2,
		messages: [
			{
				entities: [],
				avatar: true,
				from: {
					id: 1,
					name: m.name,
					photo: {
						url: pp,
					},
				},
				text: text,
				replyMessage: {},
			},
		],
	};

	const buffer = await Quotly(obj);
	let stiker = await sticker(buffer, false, global.packname, global.author);
	if (stiker) return conn.sendFile(m.chat, stiker, "Quotly.webp", "", m);
};

handler.help = ["qc *ᴛᴇxᴛ*"];
handler.tags = [ttools];
handler.command = /^(qc)$/i;
export default handler;

async function Quotly(obj) {
	let json;

	try {
		json = await axios.post(
			"https://quote-api.rippanteq7.repl.co/generate",
			obj,
			{
				headers: {
					"Content-Type": "application/json",
				},
			},
		);
	} catch (e) {
		try {
			json = await axios.post(
				"https://quote-api-1.jigarvarma2005.repl.co/generate",
				obj,
				{
					headers: {
						"Content-Type": "application/json",
					},
				},
			);
		} catch (e) {
			try {
				json = await axios.post(
					"https://qc-api.rizzlogy.repl.co/generate",
					obj,
					{
						headers: {
							"Content-Type": "application/json",
						},
					},
				);
			} catch (e) {
				try {
					json = await axios.post(
						"https://quote-api.ghost19ui.repl.co/generate",
						obj,
						{
							headers: {
								"Content-Type": "application/json",
							},
						},
					);
				} catch (e) {
					return e;
				}
			}
		}
	}

	const results = json.data.result.image;
	const buffer = Buffer.from(results, "base64");
	return buffer;
}

function getRandomHexColor() {
	return (
		"#" +
		Math.floor(Math.random() * 16777215)
			.toString(16)
			.padStart(6, "0")
	);
}
*/