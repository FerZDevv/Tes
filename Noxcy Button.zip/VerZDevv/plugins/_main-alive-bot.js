/*const { generateWAMessageFromContent, proto } = (await import('@whiskeysockets/baileys')).default
let handler = async (m, { conn, usedPrefix: _p, __dirname, args, command}) => {
let loadd = [
    "Checking Noxcy-Multidevice •",
    "Checking Noxcy-Multidevice •",
    "Checking Noxcy-Multidevice •",
    "Checking Noxcy-Multidevice • •",
    "Checking Noxcy-Multidevice • •",
    "Checking Noxcy-Multidevice • •",
    "Checking Noxcy-Multidevice • • •",
    "Checking Noxcy-Multidevice • • •",
    "Checking Noxcy-Multidevice • • •",
    "Checking Noxcy-Multidevice • • • •",
    "Checking Noxcy-Multidevice • • • •",
    "Checking Noxcy-Multidevice • • • •",
    "Checking Noxcy-Multidevice • • • • •",
    "Checking Noxcy-Multidevice • • • • •",
    "Checking Noxcy-Multidevice • • • • •",
    "Noxcy-Multidevice : Check bot processing",
    "Noxcy-Multidevice : Check bot processing",
    "Noxcy-Multidevice : Check bot processing",
    "■□□□□□□□□□   10%",
    "■■□□□□□□□□   20%",
    "■■■□□□□□□□   30%",
    "■■■■□□□□□□   40%",
    "■■■■■□□□□□   50%",
    "■■■■■■□□□□   60%",
    "■■■■■■■□□□   70%",
    "■■■■■■■■□□   80%",
    "■■■■■■■■■□   90%",
    "■■■■■■■■■■   100%",
    "■■■■■■■■■■   100%",
    "■■■■■■■■■■   100%",
    "Noxcy-Multidevice : Check bot complete",
    "Noxcy-Multidevice : Check bot complete",
    "Noxcy-Multidevice : Check bot complete",
    "Noxcy-Multidevice : Check bot complete",
    "🟢 *Noxcy-Multidevice is aktive*"
  ]
let { key } = await conn.sendMessage(m.chat, {text: 'ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . .'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
  await new Promise(resolve => setTimeout(resolve, 50));
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
}
handler.help = ['alive']
handler.tags = ['main']
handler.customPrefix = /^(.alive|bot)$/i
handler.command = new RegExp()

export default handler*/