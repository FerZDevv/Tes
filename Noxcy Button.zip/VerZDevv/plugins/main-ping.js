import speed from 'performance-now'
import { spawn, exec, execSync } from 'child_process'
let handler = async(m, {conn, usedPrefix, command }) => {
let timestamp = speed();
         let latensi = speed() - timestamp;
         exec(`neofetch --stdout`, (error, stdout, stderr) => {
          let child = stdout.toString("utf-8");
          let ssd = child.replace(/Memory:/, "Ram:");
let fer = `${ssd}🟢 *${mssg.ping}* : ${latensi.toFixed(4)} _ms_`
let from = m.key.remoteJid
let fake = { key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id: `𝙽𝙾𝚇𝙲𝚈 𝙼𝙳`, participant: '0@s.whatsapp.net' }, message: { requestPaymentMessage: { currencyCodeIso4217: "USD", amount1000: 1, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: `𝙿𝚁𝙾𝙹𝙴𝙲𝚃 𝙵𝙴𝚁𝚉𝙳𝙴𝚅𝚅` }}, expiryTimestamp: 999999999, amount: { value: 91929291929, offset: 1000, currencyCode: "USD" }}}}
const Pareploy = (teks) => { alice.sendMessage(m.chat, { text: teks, contextInfo:{ forwardingScore: 2000000000, isForwarded: false }}, { quoted : repPy })}
conn.sendMessage(m.chat, {
text: fer,
contextInfo: {
externalAdReply: {
title: namebot,
body: ``,
showAdAttribution: true,
mediaType: 1,
sourceUrl: 'https://ᴘ ᴏ ᴡ ᴇ ʀ ᴇ ᴅ  ʙ ʏ  ғ ᴇ ʀ ᴢ ᴅ ᴇ ᴠ ᴠ',
thumbnailUrl: jpg,
renderLargerThumbnail: false
}}
}, {quoted: fake})
});
}

handler.help = ['ping']
handler.tags = ['main']
handler.command = ['ping', 'speed']

export default handler
