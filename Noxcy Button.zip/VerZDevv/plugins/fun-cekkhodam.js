let handler = async(m, {conn, text}) => {
 if (!text) return m.reply('ketik nama lu anjg')
function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}
let fer = `╭━°「 *Khodam ${text}* 」°
┃• *Nama :* \`${text}\`
┊• *Khodam :* ${pickRandom([
	  "`Kaleng Cat Avian`",
	  "`Pipa Rucika`",
	  "`Botol Tupperware`",
	  "`Badut Mixue`",
	  "`Sabun GIV`",
	  "`Sandal Swallow`",
	  "`Jarjit`",
	  "`Ijat`",
	  "`Fizi`",
	  "`Mail`",
	  "`Ehsan`",
	  "`Upin`",
	  "`Ipin`",
	  "`sungut lele`",
	  "`Tok Dalang`",
	  "`Opah`",
	  "`Opet`",
	  "`Alul`",
	  "`Pak Vinsen`",
	  "`Maman Resing`",
	  "`Pak RT`",
	  "`Admin ETI`",
	  "`Bung Towel`",
	  "`Wedang Ronde`",
	  "`Kerupuk Udang`",
	  "`Cilok`",
	  "`Cilung`",
	  "`Kromboloni`",
	  "`Marmut Pink`",
	  "`Belalang Mullet`",
	  "`Kucing Oren`",
	  "`Lintah Terbang`",
	  "`Singa Paddle Pop`",
	  "`Macan Cisewu`",
	  "`Vario Mber`",
	  "`Beat Mber`",
	  "`Supra Geter`",
	  "`Oli Samping`",
	  "`Knalpot Racing`",
	  "`Air Selokan`",
	  "`Air Kobokan`",
	  "`TV Tabung`",
	  "`Keran Air`",
	  "`Tutup Panci`",
	  "`Kotak Amal`",
	  "`Tutup Termos`",
	  "`Tutup Botol`",
	  "`Kresek Item`",
	  "`Kepala Casan`",
	  "`Ban Serep`",
	  "`Kursi Lipat`",
	  "`Kursi Goyang`",
	  "`Kulit Pisang`",
	  "`Warung Madura`",
	  "`Gorong-gorong`"])}
┊• *Ada sejak:* ${pickRandom([
 "`1 tahun lalu`",
 "`2 tahun lalu`",
 "`3 tahun lalu`",
 "`4 tahun lalu`",
 "`Dari lahir`"])}
┃• *Expired :* ${pickRandom([
          "`2024`",
          "`2025`",
          "`2026`",
          "`2027`",
          "`2028`",
          "`2029`",
          "`2030`",
          "`2031`",
          "`2032`",
          "`2033`",
          "`2034`",
          "`2035`"])}
╰═┅═━┅━╍━╍═╍╍┄`
conn.sendMessage(m.chat, {
text: fer,
contextInfo: {
externalAdReply: {
title: namebot,
body: ``,
showAdAttribution: true,
mediaType: 1,
sourceUrl: 'https://ᴘ ᴏ ᴡ ᴇ ʀ ᴇ ᴅ  ʙ ʏ  ғ ᴇ ʀ ᴢ ᴅ ᴇ ᴠ ᴠ',
thumbnailUrl: jpg,
renderLargerThumbnail: false
}}
}, {quoted: m})
}
handler.help = ['cekkhodam']
handler.tags = ['main', 'xyz', 'fun']
handler.command = ['cekkhodam', 'cekkodam']
export default handler
