import fetch from "node-fetch"

let handler = async(m, {conn}) => {

let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
let muptime = clockString(_muptime)
let tem = `${muptime}`
let thumb = global.jpg
let anjay = `./vn/swetlove.opus`
conn.sendFile(m.chat, anjay, "Hayanasi-mp3", null, m, true, {
		type: 'audioMessage',  
 ptt: true, 
seconds: 9999999999,
fileLength: 18,
 ptt: true, contextInfo: { forwardingScore: 999, isForwarded: true, forwardedNewsletterMessageInfo: { newsletterName: `🔴 Bot Online For ` + tem,
newsletterJid: '777@newsletter'}, externalAdReply: {title: namebot, body: botdate, sourceUrl: 'https://www.tiktok.com/@oscarduaa', thumbnail: await (await fetch(thumb)).buffer(),}}  
  }) 
  }
  handler.command = /^(tes)$/i
  export default handler
  function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [d, 'd ', h, 'h ', m, 'm ', s, 's '].map(v => v.toString().padStart(1, 0)).join('')
}