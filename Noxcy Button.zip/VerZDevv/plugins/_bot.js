let handler = async(m, {conn}) => {
let fer = `🟢 𝐍𝐨𝐱𝐜𝐲 𝐌𝐃 𝐈𝐬 𝐀𝐜𝐭𝐢𝐯𝐞`
let from = m.key.remoteJid
let fake = { key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id: `𝙽𝙾𝚇𝙲𝚈 𝙼𝙳`, participant: '0@s.whatsapp.net' }, message: { requestPaymentMessage: { currencyCodeIso4217: "USD", amount1000: 1, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: `𝙿𝚁𝙾𝙹𝙴𝙲𝚃 𝙵𝙴𝚁𝚉𝙳𝙴𝚅𝚅` }}, expiryTimestamp: 999999999, amount: { value: 91929291929, offset: 1000, currencyCode: "USD" }}}}
const Pareploy = (teks) => { alice.sendMessage(m.chat, { text: teks, contextInfo:{ forwardingScore: 2000000000, isForwarded: false }}, { quoted : repPy })}
conn.sendMessage(m.chat, {
text: fer,
contextInfo: {
externalAdReply: {
title: namebot,
body: ``,
showAdAttribution: true,
mediaType: 1,
sourceUrl: 'https://ᴘ ᴏ ᴡ ᴇ ʀ ᴇ ᴅ  ʙ ʏ  ғ ᴇ ʀ ᴢ ᴅ ᴇ ᴠ ᴠ',
thumbnailUrl: jpg,
renderLargerThumbnail: false
}}
}, {quoted: fake})
}
handler.customPrefix = /^(bot|nox)$/i
handler.command = new RegExp()

export default handler