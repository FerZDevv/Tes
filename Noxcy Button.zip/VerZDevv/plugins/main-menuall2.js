//import db from '../lib/database.js'
import { promises } from 'fs'
import { join } from 'path'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
import moment from "moment-timezone"
//import { plugins } from '../lib/plugins.js'
let tags = {
  'main': 'ᴍᴀɪɴ',
  'info': 'ɪɴғᴏ',
  'xyz': 'ᴘᴏᴘᴜʟᴇʀ',
  'ai': 'ᴏᴘᴇɴᴀɪ',
  'jadibot': 'ᴊᴀᴅɪʙᴏᴛ',
  'game': 'ɢᴀᴍᴇ',
  'audio': 'ᴀᴜᴅɪᴏ ᴇғғᴇᴄᴛ',
  'warmode': 'ʙᴜɢ & ᴡᴀʀ',
  'econ': 'ᴇᴄᴏɴ',
  'rg': 'ᴅᴀғᴛᴀʀ',
  'sticker': 'sᴛɪᴄᴋᴇʀ',
  'img': 'ɪᴍᴀɢᴇ',
  'maker': 'ᴍᴀᴋᴇʀ',
  'prem': 'ᴘʀᴇᴍɪᴜᴍ',
  'group': 'ɢʀᴏᴜᴘ',
  'nable': 'ᴇɴᴀʙʟᴇ/ᴅɪsᴀʙʟᴇ', 
  'nime': 'ᴀɴɪᴍᴇ',
  'rnime': 'ᴀɴɪᴍᴇ ʀᴇᴀᴄᴄɪᴏɴ',
  'dl': 'ᴅᴏᴡɴʟᴏᴀᴅᴇʀ',
  'tools': 'ᴛᴏᴏʟs',
  'fun': 'ғᴜɴ',
  'lolmaker': 'ʟᴏʟ-ᴍᴀᴋᴇʀ',
  'cmd': 'ᴅᴀᴛᴀʙᴀsᴇ',
  'nsfw': 'ɴsғᴡ +18',
  'ansfw': 'ɴsғᴡ ᴀɴɪᴍᴇ', 
  'owner': 'ᴏᴡɴᴇʀ', 
  'advanced': 'ᴀᴅᴠᴀɴᴄᴇ',
}
const defaultMenu = {
  before: `
_Hai 👋, %ucapan_
> ╭─ • ᯓ★ [ ɪ ɴ ғ ᴏ  ʙ ᴏ ᴛ ]
> │  ≡ [ *ɴᴀᴍᴇ ʙᴏᴛ* : Nᴏxᴄʏ - MD ]
> │  ≡ [ *ᴅᴀᴛᴇ* : %date  ]
> │  ≡ [ *ᴜᴘᴛɪᴍᴇ* : %muptime ]
> ╰─╍━╍╍┄ •
> ╭─ • ᯓ★ [ ɪ ɴ ғ ᴏ  ᴜ s ᴇ ʀ ]
> │  ≡ [ *ʜᴀʟᴏ!* : *%name* ]
> │  ≡ [ *ʟᴇᴠᴇʟ* : %level ]
> │  ≡ [ *ʟɪᴍɪᴛ* : %diamond ]
> │  ≡ [ *ʀᴏʟᴇ* : %role ]
> │  ≡ [ *ᴛᴏᴛᴀʟ ᴜsᴇʀ* : %totalreg ]
> ╰─╍━╍╍┄ •
%readmore
%sbot
╭─ • ⚠︎ *ɪɴғᴏʀᴍᴀsɪ*
- ⓓ ➠ ʟɪᴍɪᴛ 💎
- Ⓟ ➠ ᴘʀᴇᴍɪᴜᴍ
╰──── •
`.trimStart(),
  header: '╔₍⚡₎❝┊\`\`   \`⏤͟͟͞͞ᵡ %category\`',
  body: '│ ° 🔹️ _%cmd_ %isdiamond %isPremium',
  footer: '╚════════╍━╍╍┄',
  after: NSnama,
}
let handler = async (m, { conn, usedPrefix: _p, __dirname }) => {
  try {
    let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
    let { exp, diamond, level, role } = global.db.data.users[m.sender]
    let { min, xp, max } = xpRange(level, global.multiplier)
    let name = await conn.getName(m.sender)
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d)
    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
    let _uptime = process.uptime() * 1000
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        diamond: plugin.diamond,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      }
    })
    for (let plugin of help)
      if (plugin && 'tags' in plugin)
        for (let tag of plugin.tags)
          if (!(tag in tags) && tag) tags[tag] = tag
    conn.menu = conn.menu ? conn.menu : {}
    let before = conn.menu.before || defaultMenu.before
    let header = conn.menu.header || defaultMenu.header
    let body = conn.menu.body || defaultMenu.body
    let footer = conn.menu.footer || defaultMenu.footer
    let after = conn.menu.after || (conn.user.jid == conn.user.jid ? '' : `⭐ ᴘᴏᴡᴇʀᴇᴅ ʙʏ @ғᴇʀᴢᴅᴇᴠ xᴅ https://wa.me/${conn.user.jid.split`@`[0]}`) + defaultMenu.after
    let _text = [
      before,
      ...Object.keys(tags).map(tag => {
        return header.replace(/%category/g, tags[tag]) + '\n' + [
          ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
            return menu.help.map(help => {
              return body.replace(/%cmd/g, menu.prefix ? help : '%p' + help)
                .replace(/%isdiamond/g, menu.diamond ? '(ⓓ)' : '')
                .replace(/%isPremium/g, menu.premium ? '(Ⓟ)' : '')
                .trim()
            }).join('\n')
          }),
          footer
        ].join('\n')
      }),
      after
    ].join('\n')
    let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
    let replace = {
      '%': '%',
      p: _p, uptime, muptime,
      me: conn.getName(conn.user.jid),
      sbot: (conn.user.jid == global.conn.user.jid ? '' : `\n▢ ✨ *Sub-Bot:*\nwa.me/${global.conn.user.jid.split`@`[0]}`), 
      npmname: _package.name,
      ucapan: ucapan(),
      npmdesc: _package.description,
      version: _package.version,
      exp: exp - min,
      maxexp: xp,
      totalexp: exp,
      xp4levelup: max - exp,
      github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
      level, diamond, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role,
      readmore: readMore
    }
    text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
    
    let pp = './src/fg_logo.jpg'

    /*conn.sendButton(m.chat, text.trim(), `▢ DyLux  ┃ ᴮᴼᵀ\n${mssg.ig}`, pp, [
      ['ꨄ︎ Apoyar', `${_p}donate`],
      ['⏍ Info', `${_p}botinfo`],
      ['⌬ Grupos', `${_p}gpdylux`]
    ], m, rpl)*/
let loadd = [
    "■□□□□□□□□□\n             10٪",
    "■■□□□□□□□□\n             20٪",
    "■■■□□□□□□□\n             30٪",
    "■■■■□□□□□□\n             40٪",
    "■■■■■□□□□□\n             50٪",
    "■■■■■■□□□□\n             60٪",
    "■■■■■■■□□□\n             70٪",
    "■■■■■■■■□□\n             80٪",
    "■■■■■■■■■□\n             90٪",
    "■■■■■■■■■■\n             100٪",
    "ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ  ᴄ ᴏ ᴍ ᴘ ʟ ᴇ ᴛ ᴇ . . ."
  ]

let { key } = await conn.sendMessage(m.chat, {text: 'ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . .'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
  await new Promise(resolve => setTimeout(resolve, 100));
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
    conn.sendMessage(m.chat, {
text: text,
contextInfo: {
externalAdReply: {
title: "ɴ ᴏ x ᴄ ʏ  ʙ ᴏ ᴛ ᴢ  ᴡ ʜ ᴀ ᴛ s ᴀ ᴘ ᴘ",
body: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ FᴇʀZDᴇᴠᴠ⚡",
thumbnailUrl: NSthumb,
sourceUrl: NSgc,
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})

/*let vn = "./vn/menu.mp3"
      
	conn.sendFile(m.chat, vn, "ehee.mp3", null, m, true, {
		type: "audioMessage",
		ptt: true,
	});*/
    conn.sendMessage(m.chat, {
          react: {
            text: `✅`,
            key: m.key,
          }})
  } catch (e) {
    conn.reply(m.chat, '❎ Maaf, menu mengalami kesalahan', m)
    throw e
  }
}
//handler.help = ['help']
//handler.tags = ['main']
handler.command = ['allmenu2', 'menuall2']
handler.register = false

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [d, 'ᴅ ', h, 'ʜ ', m, 'ᴍ '].map(v => v.toString().padStart(2, 0)).join('')
}
function ucapan() {
        const hour_now = moment.tz('Asia/Jakarta').format('HH')
        var ucapanWaktu = 'Selamat pagi kak 🌄'
        if (hour_now >= '03' && hour_now <= '10') {
          ucapanWaktu = 'Selamat pagi kak 🌄'
        } else if (hour_now >= '10' && hour_now <= '15') {
          ucapanWaktu = 'Siang kak ☀️'
        } else if (hour_now >= '15' && hour_now <= '17') {
          ucapanWaktu = 'Sore kek 🌇'
        } else if (hour_now >= '17' && hour_now <= '18') {
          ucapanWaktu = 'Petang kak 🌆'
        } else if (hour_now >= '18' && hour_now <= '23') {
          ucapanWaktu = 'Selamat malam kak 🌙'
        } else {
          ucapanWaktu = 'Selamat malam kak! 🌙'
        }	
        return ucapanWaktu
}