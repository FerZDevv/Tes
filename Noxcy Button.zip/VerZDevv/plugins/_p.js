/*import fetch from 'node-fetch'
let handler = async (m, { conn, text, args }) => {
let peler = '*Aᴘᴀᴀɴ Kᴏɴᴛᴏʟ. Pᴀ Pᴇ Pᴀ Pᴇ Aᴊᴀ Lᴜ Bᴀɴɢsᴀᴅᴅ*'
conn.sendPresenceUpdate('recording', m.chat)
conn.fakeReply(m.chat, peler, '0@s.whatsapp.net', '*Sᴀʟᴀᴍ Dᴜʟᴜ Aɴᴊɢ*', 'status@broadcast')
}
handler.customPrefix = /^(P|pp)$/i;
handler.command = new RegExp()

export default handler*/

let handler = async(m, {conn}) => {
let fer = `*Apaan Kontoll. Pa Pe Pa Pe Aja Lu Bangsadd.*`
let from = m.key.remoteJid
let fake = { key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id: `𝙽𝙾𝚇𝙲𝚈 𝙼𝙳`, participant: '0@s.whatsapp.net' }, message: { requestPaymentMessage: { currencyCodeIso4217: "USD", amount1000: 1, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: `𝙿𝚁𝙾𝙹𝙴𝙲𝚃 𝙵𝙴𝚁𝚉𝙳𝙴𝚅𝚅` }}, expiryTimestamp: 999999999, amount: { value: 91929291929, offset: 1000, currencyCode: "USD" }}}}
const Pareploy = (teks) => { alice.sendMessage(m.chat, { text: teks, contextInfo:{ forwardingScore: 2000000000, isForwarded: false }}, { quoted : repPy })}
conn.sendMessage(m.chat, {
text: fer,
contextInfo: {
externalAdReply: {
title: '𝙎𝙖𝙡𝙖𝙢 𝘿𝙪𝙡𝙪 𝘼𝙣𝙟𝙜',
body: ``,
showAdAttribution: true,
mediaType: 1,
sourceUrl: 'https://ᴘ ᴏ ᴡ ᴇ ʀ ᴇ ᴅ  ʙ ʏ  ғ ᴇ ʀ ᴢ ᴅ ᴇ ᴠ ᴠ',
thumbnailUrl: jpg,
renderLargerThumbnail: false
}}
}, {quoted: fake})
}
handler.customPrefix = /^(P|pp)$/i;
handler.command = new RegExp()

export default handler