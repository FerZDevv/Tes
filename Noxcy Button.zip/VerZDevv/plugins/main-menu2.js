let handler = async(m, {conn, usedPrefix, command }) => {

let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
let fer = `*ʜᴀʟᴏ ${conn.getName(m.sender)}*

${global.NSprf}乂  B O T  I N F O${global.NSprf}*

> ⌬〡 *ɴᴀᴍᴇ ʙᴏᴛ* : ᴢᴇʀᴏ-ᴀɪ
> ⌬〡 *ᴄʀᴇᴀᴛᴏʀ* : @ғᴇʀᴢᴅᴇᴠ xᴅ
> ⌬〡︎ *ᴘʟᴀᴛғᴏʀᴍ* : ʟɪɴᴜx
> ⌬〡︎ *ᴛʏᴘᴇ sᴄʀɪᴘᴛ* : ᴘʟᴜɢɪɴs
> ⌬〡 *ᴜᴘᴛɪᴍᴇ* : ${muptime}
> ⌬〡 *ᴛʏᴘᴇ* : ɴᴏᴅᴇ.ᴊs

> > > > > > > > > > > > > > > > >
${global.NSprf}ᴜɴᴛᴜᴋ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ sᴇᴍᴜᴀ ғɪᴛᴜʀ ᴋᴇᴛɪᴋ .ᴀʟʟᴍᴇɴᴜ${global.NSprf}

> • ᴊɪᴋᴀ ᴀᴅᴀ ꜰɪᴛᴜʀ yᴀɴɢ ᴇʀᴏʀ ꜱɪʟᴀʜᴋᴀɴ ᴋᴇᴛɪᴋ *.ʀᴇᴘᴏʀᴛ (ᴋᴇᴛᴇʀᴀɴɢᴀɴ)*
> • ɴᴏᴛᴇ: ᴊɪᴋᴀ ᴀɴᴅᴀ ᴛɪᴅᴀᴋ ᴛᴀʜᴜ ᴄᴀʀᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴏᴛ, ᴀɴᴅᴀ ᴅᴀᴩᴀᴛ ᴍᴇɴɢᴇᴛɪᴋ *.ᴛᴜᴛᴏʀɪᴀʟ*
> > > > > > > > > > > > > > > > >`
let thumb = 'https://a.uguu.se/NsyhblYG.mp4'

conn.sendFile(m.chat, thumb, 'ɪᴛᴀᴄʜɪ - ᴍᴅ', fer, m, null, rffp)

let tek = `
ᴘᴏᴡᴇʀᴇᴅ ʙʏ: @ғᴇʀᴢᴅᴇᴠ xᴅ
`
let vit = './vn/tucadonca.mp3'

conn.sendFile(m.chat, vit, 'crash.mp3', tek, null, m)
	
	/*let ft = "./thumbnail.jpg"
      
	conn.sendFile(m.chat, ft, "wk.jpg", null, m, true, {
		type: "img",
		img: true,
	});*/
}

handler.command = ('menu2')

export default handler

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [d, 'ᴅ ', h, 'ʜ ', m, 'ᴍ ', s, 's '].map(v => v.toString().padStart(1, 0)).join('')
}