import fs from 'fs';
let handler = async(m, {conn, usedPrefix, command }) => {
let fitur = Object.values(plugins).filter(v => v.help && !v.disabled).map(v => v.help).flat(1)
let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags
  ).length;
let fer = ` 
Fitur Total Bot Saat Ini: \n*🔖 Plugins :* ±${totalf} Plugins Files\n*🔖 Fitur :* ±${fitur.length} Menu`
let thumb = 'https://a.uguu.se/NsyhblYG.mp4'
let from = m.key.remoteJid
let fake = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? {remoteJid: "status@broadcast"} : {})}, message: {extendedTextMessage: {text: `_Noxcy MD Terverifikasi Oleh WhatsApp_`}}}
conn.sendFile(m.chat, thumb, 'ᴛ ᴏ ᴛ ᴀ ʟ  ғ ᴇ ᴀ ᴛ ᴜ ʀ ᴇ s', fer, fake, null, rffp)
}

handler.help = ['totalfitur']
handler.tags = ['info']
handler.command = ['totalfitur']
export default handler