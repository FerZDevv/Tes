let nansoffc = async(m, { conn, text, participants }) => {
  const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)
  let teks = `.═━┅━╍ { *𝐓𝐀𝐆 𝐀𝐋𝐋* } ═┅═━┅.\n> ${text ? text : 'Nothing'}\n${readMore}\n╭─ • *TAGALL*\n`
		      	for (let mem of participants) {
		            teks += `│ • @${mem.id.split('@')[0]}\n`
				}
                teks += `╰═┅═━┅━╍━╍═╍╍┄•`
                conn.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, )
}
nansoffc.help = ['tagall <pesan>']
nansoffc.tags = ['group']
nansoffc.command = /^(tagall)$/i

nansoffc.group = true
nansoffc.admin = true

export default nansoffc