import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['ᴘᴀʜɪɴɢ', 'ᴘᴏɴ', 'ᴡᴀɢᴇ', 'ᴋʟɪᴡᴏɴ', 'ʟᴇɢɪ'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })

global.owner = [
  ['6285878075754', 'FᴇʀZDᴇᴠᴠ', true],
  ['62895355636551', 'ᯓ★ Nᴏxᴄʏ - MD (ʙᴏᴛᴢ)', true]
] // nomor owner

global.mods = ['6285878075754'] 
global.prems = ['6285878075754', '62895355636551']
global.noowner = '6285878075754'
global.APIs = { // API Prefix
  // name: 'https://website' 
  nrtm: 'https://fg-nrtm.ddns.net',
  lann: 'https://api.betabotz.eu.org'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.betabotz.eu.org': 'fyUnm7GI'
}

// daftar di sini https://api.betabotz.eu.org
global.lann = 'fyUnm7GI'
global.lolkey = 'f2707993c4db1ce11209da14' // apikey lol human

// setting limit user
global.limit = 69

// Nama Botz
global.namebot = 'ᯓ★ 𝐍𝐨𝐱𝐜𝐲 - 𝐌𝐃'

// Sticker WM
global.packname = 'ᯓ★ 𝐍𝐨𝐱𝐜𝐲 - 𝐌𝐃\n\n\nᴘᴏᴡᴇʀᴇᴅ ʙʏ:\n\nғ\nᴇ\nʀ\nᴢ\nᴅ\nᴇ\nᴠ\n\nx\nᴅ' 
global.author = 'VᴇʀZDᴇᴠᴠ' 
global.botdate = `Day's: ${week} ${date}`
//--info NS [ NANS ]
global.NSnama = 'ᯓ★ Nᴏxᴄʏ MD Bᴏᴛᴢ WʜᴀᴛsAᴘᴘ\nFᴇʀZDᴇᴠᴠ'
global.NSferdev = 'ᴘ ᴏ ᴡ ᴇ ʀ ᴇ ᴅ  ʙ ʏ  ғ ᴇ ʀ ᴢ ᴅ ᴇ ᴠ ᴠ'
global.cr = '© Copyright VerZDevv - 2024'
global.NSig = 'https://www.instagram.com/ferzdevxd' 
global.NSgc = 'https://whatsapp.com/channel/0029VaBl0VOAInPsCK1JJG3A'
global.NSthumb = 'https://telegra.ph/file/b1c671088003f3ddd9937.jpg'
global.NSfer = 'https://telegra.ph/file/6ff2b6ce8e6c1d3348549.jpg'
global.jpg = 'https://telegra.ph/file/42f914b2329902f68597c.jpg'
global.NSprf = '`'

global.wait = '*⌛ _ʟᴏᴀᴅɪɴɢ..._*\n> *▰▰▰▱▱▱▱▱*'
global.eror = '_ᴇʀʀᴏʀ, ᴋᴇsᴀʟᴀʜᴀɴ ᴛɪᴅᴀᴋ ᴛᴇʀᴅᴜɢᴀ_'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // max warning

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})